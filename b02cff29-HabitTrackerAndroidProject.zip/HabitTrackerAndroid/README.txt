HABIT TRACKER ANDROID PROJECT (v1.1)

This is an Android Studio project wrapping the single-page Habit Tracker HTML app in a native Android WebView. The APK itself is not included because this environment has no Android SDK/build tools installed.

BUILD APK:
1. Install Android Studio on a computer and open this HabitTracker folder as a project.
2. Allow Android Studio to install the Android SDK (API 35) and sync Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

APP DETAILS:
- App label: Habit Tracker
- Package: com.pratyush.habittracker
- Minimum Android: 6.0 (API 23)
- Offline HTML asset, no internet permission, no backend.
- Progress is stored in WebView local storage. Clearing app data/uninstalling may erase it.

NOTE: Build with a compatible recent Android Studio/Gradle setup. This project has not been compiled here because the Android SDK and Gradle are unavailable in the build environment.
